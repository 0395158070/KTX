﻿using KTX.Properties;
using KTX.Shared;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Resources;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KTX
{
    public partial class FormKTX : Form
    {
        KTX.QLKTXEntities db = new QLKTXEntities();
        private List<KyTucXa> x;
        public FormKTX()
        {
            InitializeComponent();
            x = db.KyTucXas.ToList();
            comboBox1.DataSource = x;
            comboBox1.DisplayMember = "MaKyTucXa";
            comboBox1.ValueMember = "Id";
        }

        private void FormKTX_Load(object sender, EventArgs e)
        {
           


        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(comboBox1.SelectedIndex >= 0)
            {
                var y = ((KyTucXa)comboBox1.SelectedItem).KhuKyTucXas.ToList();
                if(y.Count > 0)
                {
                    comboBox2.DataSource = y;
                    comboBox2.DisplayMember = "Ten";
                    comboBox2.ValueMember = "Id";
                }
                else
                {
                    comboBox2.DataSource = null;
                    comboBox2.Text = "";
                    comboBox3.DataSource = null;
                    comboBox3.Text = "";
                }
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.SelectedIndex >= 0)
            {
                var y = ((KhuKyTucXa)comboBox2.SelectedItem).NhaKyTucXas.ToList();
                if (y.Count > 0)
                {
                    comboBox3.DataSource = y;
                    comboBox3.DisplayMember = "Ten";
                    comboBox3.ValueMember = "Id";
                }
                else
                {
                    comboBox3.DataSource = null;
                    comboBox3.Text = "";

                }
            }
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox3.SelectedIndex >= 0)
            {
                listView1.Items.Clear();
                var y = ((NhaKyTucXa)comboBox3.SelectedItem).PhongKyTucXas.ToList();
                var imageList = new ImageList();
                imageList.Images.Add("itemImageKey", Resources.key);
                imageList.ImageSize = new Size(32, 32);
                listView1.LargeImageList = imageList;
                foreach (var item in y)
                {
                    int count = db.PhanPhoiSinhViens.Where(p => p.ID_PhongKyTucXa == item.ID).ToList().Count;
                    listView1.Items.Add(new ListViewItem() {Tag = item.ID, Text = item.TenPhong + "\r\n" + "Số người: " + count, ImageKey = "itemImageKey" });
                }
               
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                PhanPhoi f = new PhanPhoi(int.Parse(listView1.SelectedItems[0].Tag.ToString()));
                f.MdiParent = StaticForm.Main;
                f.Show();
            }
            catch
            {

            }
        }
    }
}
