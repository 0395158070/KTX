﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// thông tin chung về lắp ráp được kiểm soát thông qua những điều sau
// tập hợp các thuộc tính. thay đổi các giá trị thuộc tính này để sửa đổi thông tin
// liên kết với một hội đồng
[assembly: AssemblyTitle("KTX")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("KTX")]
[assembly: AssemblyCopyright("Copyright ©  2018")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Đặt ComVisible thành false làm cho các loại trong cụm này không hiển thị
// thành phần COM.Nếu bạn cần truy cập một loại trong hội đồng này từ
// COM, đặt thuộc tính ComVisible thành true trên loại đó.
[assembly: ComVisible(false)]

// GUID sau đây dành cho ID của typelib nếu dự án này được hiển thị với COM
[assembly: Guid("246ff935-3063-49ac-beb7-7a024bfaa5c2")]

// Thông tin phiên bản cho một hội đồng bao gồm bốn giá trị sau:
//
//      phiên bản chính
//      phiên bản nhỏ
//      số lượng xây dựng
//      sửa đổi
//
// có thể chỉ định tất cả các giá trị hoặc có thể mặc định số xây dựng và sửa đổi
// bằng cách sử dụng '*' như hiển thị bên dưới:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
