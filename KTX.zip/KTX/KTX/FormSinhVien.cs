﻿using KTX.Properties;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KTX
{
    public partial class FormSinhVien : Form
    {
        KTX.QLKTXEntities db = new QLKTXEntities();
        bool isThem = false;
        string imagePath = "";
        SinhVien selectedSV = null;

        public Image Resource { get; private set; }

        public FormSinhVien()
        {
            InitializeComponent();
        }

        private void FormSinhVien_Load(object sender, EventArgs e)
        {
            ReloadDataGrid();
            isThem = ButtonStatus(false);
            groupBox1.Enabled = false;
        }

        private void bttThem_Click(object sender, EventArgs e)
        {
            
           
            if (!isThem)
            {
                isThem = ButtonStatus(true);
                groupBox1.Enabled = true;
                

            }
            else
            {
                //Lưu Sinh viên
                SinhVien sv = new SinhVien();
                sv.MaSinhVien = txtMaSV.Text;
                sv.TenSinhVien = txtTen.Text;
                sv.DienThoai = txtDienThoai.Text;
                sv.NgaySinh = txtNgaySinh.Value;
                sv.DiaChi = txtDiaChi.Text;
                sv.GIoiTinh = txtGioiTinh.Checked;
                sv.Image = imagePath;
                db.SinhViens.Add(sv);
                db.SaveChanges();
                ReloadDataGrid();
                imagePath = "";
                isThem = ButtonStatus(false);
            }
        }
        private bool ButtonStatus(bool them)
        {
            if(them)
            {
                bttSua.Visible = true;
                bttChonHinh.Enabled = true;
                bttThem.Text = "Lưu";
                bttSua.Text = "Huỷ";
                txtMaSV.Text = "";
                txtTen.Text = "";
                txtDienThoai.Text = "";
                txtNgaySinh.Value = DateTime.Now;
                txtDiaChi.Text = "";
            }
            else
            {
                bttThem.Text = "Thêm";
                bttSua.Visible = false;
                imagePath = "";
                groupBox1.Enabled = false;
                bttChonHinh.Enabled = false;
                return false;
            }
            return true;
        }
        private void ReloadDataGrid()
        {
            dataGridView1.DataSource = null;

            DataTable dt = new DataTable();
            dt.Columns.Add("ID");
            dt.Columns.Add("Mã sinh viên");
            dt.Columns.Add("Tên sinh viên");
            dt.Columns.Add("Địa chỉ");
            dt.Columns.Add("Giới tính");
            var x = db.SinhViens.ToList();
            foreach (var item in x)
            {
                dt.Rows.Add(item.ID, item.MaSinhVien, item.TenSinhVien, item.DiaChi, item.GIoiTinh == true ? "Nam" : "Nữ");
            }
            dataGridView1.DataSource = dt;
        }

        private void bttChonHinh_Click(object sender, EventArgs e)
        {
            OpenFileDialog fd = new OpenFileDialog() {
                Multiselect = false };
            if(fd.ShowDialog() == DialogResult.OK)
            {
                pictureBox1.ImageLocation = fd.FileName;
                string random = Guid.NewGuid().ToString();
                File.Copy(fd.FileName, AppDomain.CurrentDomain.BaseDirectory + "/Images/" + random + Path.GetExtension(fd.FileName));
                imagePath = AppDomain.CurrentDomain.BaseDirectory + "Images/" + random + Path.GetExtension(fd.FileName);
            }
        }

        private void bttSua_Click(object sender, EventArgs e)
        {

            if (!isThem)
            {
                selectedSV.MaSinhVien = txtMaSV.Text;
                selectedSV.TenSinhVien = txtTen.Text;
                selectedSV.DienThoai = txtDienThoai.Text;
                selectedSV.NgaySinh = txtNgaySinh.Value;
                selectedSV.DiaChi = txtDiaChi.Text;
                selectedSV.GIoiTinh = txtGioiTinh.Checked;
                selectedSV.Image = imagePath;
                db.SaveChanges();
                ReloadDataGrid();
                selectedSV = null;
                isThem = ButtonStatus(false);
            }
            isThem = ButtonStatus(false);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           

        }

        private void bttXoa_Click(object sender, EventArgs e)
        {
            if(dataGridView1.SelectedRows[0].Cells[0] != null && dataGridView1.SelectedRows[0].Cells[0].Value != null)
            {
                int idsv = int.Parse(dataGridView1.SelectedRows[0].Cells[0].Value.ToString());
                var x = db.SinhViens.Where(p => p.ID == idsv).First();
                db.SinhViens.Remove(x);
                db.SaveChanges();
                ReloadDataGrid();
            }
            else
            {
                MessageBox.Show("Bạn chưa chọn sinh viên");
            }
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                string idsv = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
                int id = int.Parse(idsv);
                var x = db.SinhViens.Where(p => p.ID == id).First();
                isThem = false;
                bttSua.Text = "Sửa";
                if (x.Image != null && x.Image != "")
                {
                    txtMaSV.Text = x.MaSinhVien;
                    txtTen.Text = x.TenSinhVien;
                    txtDienThoai.Text = x.DienThoai;
                    txtNgaySinh.Value = x.NgaySinh.Value;
                    txtDiaChi.Text = x.DiaChi;
                    txtGioiTinh.Checked = x.GIoiTinh.Value;
                    pictureBox1.Image = Image.FromFile(x.Image);
                    bttChonHinh.Enabled = true;
                    bttSua.Visible = true;
                    groupBox1.Enabled = true;
                    selectedSV = x;
                }
                else
                {
                    txtMaSV.Text = x.MaSinhVien;
                    txtTen.Text = x.TenSinhVien;
                    txtDienThoai.Text = x.DienThoai;
                    txtNgaySinh.Value = x.NgaySinh.Value;
                    txtDiaChi.Text = x.DiaChi;
                    txtGioiTinh.Checked = x.GIoiTinh.Value;
                    pictureBox1.Image = Resources.noavatar;
                    bttChonHinh.Enabled = true;
                    bttSua.Visible = true;
                    groupBox1.Enabled = true;
                    selectedSV = x;
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
                pictureBox1.Image = Resources.noavatar;
                txtMaSV.Text = "";
                txtTen.Text = "";
                txtDienThoai.Text = "";
                txtNgaySinh.Value = DateTime.Now;
                txtDiaChi.Text = "";
                txtGioiTinh.Checked = false;
                bttChonHinh.Enabled = false;
                bttSua.Visible = false;
                groupBox1.Enabled = false;
                selectedSV = null;
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            var x = db.SinhViens.Where(p => p.MaSinhVien.ToLower().Contains(txtSearch.Text)).ToList();
            ReloadDataGrid2(x);
        }

        private void ReloadDataGrid2(List<SinhVien> _list)
        {
            dataGridView1.DataSource = null;

            DataTable dt = new DataTable();
            dt.Columns.Add("ID");
            dt.Columns.Add("Mã sinh viên");
            dt.Columns.Add("Tên sinh viên");
            dt.Columns.Add("Địa chỉ");
            dt.Columns.Add("Giới tính");
            foreach (var item in _list)
            {
                dt.Rows.Add(item.ID, item.MaSinhVien, item.TenSinhVien, item.DiaChi, item.GIoiTinh == true ? "Nam" : "Nữ");
            }
            dataGridView1.DataSource = dt;
        }
    }
}
