﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KTX
{
    public partial class PhanPhoi : Form
    {
        KTX.QLKTXEntities db = new QLKTXEntities();
        int idPhong = 0;
        PhongKyTucXa phong = null;
        public PhanPhoi(int _id)
        {
            idPhong = _id;
            InitializeComponent();
        }

        private void PhanPhoi_Load(object sender, EventArgs e)
        {
            phong = db.PhongKyTucXas.Where(p => p.ID == idPhong).First();
            this.Text = "Phân phối sinh viên cho phòng: " + phong.TenPhong;
            List<SinhVien> listSV = new List<SinhVien>();

            var x = db.PhanPhoiSinhViens.Where(p => p.ID_PhongKyTucXa == phong.ID).ToList();
            foreach (var item in x)
            {
                listSV.Add(item.SinhVien);
            }

            LoadDataGrid2(listSV);
            label3.Text = "";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            var x = db.SinhViens.Where(p => p.MaSinhVien.ToLower().Contains(textBox1.Text)).ToList();
            LoadDataGrid1(x);
        }
        private void LoadDataGrid1(List<SinhVien> _listSV)
        {
            dataGridView1.DataSource = null;

            DataTable dt = new DataTable();
            dt.Columns.Add("IDSV");
            dt.Columns.Add("Mã SV");
            dt.Columns.Add("Tên SV");

            foreach(SinhVien sv in _listSV)
            {
                dt.Rows.Add(sv.ID, sv.MaSinhVien, sv.TenSinhVien);
            }

            dataGridView1.DataSource = dt;
            label3.Text = "";
        }
        private void LoadDataGrid2(List<SinhVien> _listSV)
        {
            dataGridView2.DataSource = null;

            DataTable dt = new DataTable();
            dt.Columns.Add("IDSV");
            dt.Columns.Add("Mã SV");
            dt.Columns.Add("Tên SV");

            foreach (SinhVien sv in _listSV)
            {
                dt.Rows.Add(sv.ID, sv.MaSinhVien, sv.TenSinhVien);
            }

            dataGridView2.DataSource = dt;
            label2.Text = "";
        }
        SinhVien sv = null;
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                this.label3.Text = "Bạn đang chọn sinh viên : " + dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
                int idsv = int.Parse(dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString());
                sv = db.SinhViens.Where(p => p.ID == idsv).First();
            }
            catch
            {
                sv = null;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(sv != null)
            {
                //Thêm sinh viên vào phòng.
                int limit = phong.GioiHan.Value;
                if(db.PhanPhoiSinhViens.Where(p => p.ID_PhongKyTucXa == phong.ID && p.ID_SinhVien == sv.ID).ToList().Count > 0)
                {
                    MessageBox.Show("Sinh viên " + sv.TenSinhVien  + " đã ở ở phòng này");
                    return;
                }
                if(db.PhanPhoiSinhViens.Where(p=>p.ID_PhongKyTucXa == phong.ID).ToList().Count >= limit)
                {
                    MessageBox.Show("Đã quá số lượng người cho phép");
                }
                else
                {
                    PhanPhoiSinhVien pp = new PhanPhoiSinhVien();
                    pp.PhongKyTucXa = phong;
                    pp.SinhVien = sv;
                    db.PhanPhoiSinhViens.Add(pp);
                    db.SaveChanges();

                    List<SinhVien> listSV = new List<SinhVien>();

                    var x = db.PhanPhoiSinhViens.Where(p => p.ID_PhongKyTucXa == phong.ID).ToList();
                    foreach(var item in x)
                    {
                        listSV.Add(item.SinhVien);
                    }

                    LoadDataGrid2(listSV);
                }
            }
            else
            {
                MessageBox.Show("Bạn chưa chọn sinh viên nào");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(sv2 != null)
            {
                var x = db.PhanPhoiSinhViens.Where(p => p.ID_PhongKyTucXa == phong.ID && p.ID_SinhVien == sv2.ID).First();
                db.PhanPhoiSinhViens.Remove(x);
                db.SaveChanges();

                List<SinhVien> listSV = new List<SinhVien>();

                var x1 = db.PhanPhoiSinhViens.Where(p => p.ID_PhongKyTucXa == phong.ID).ToList();
                foreach (var item in x1)
                {
                    listSV.Add(item.SinhVien);
                }

                LoadDataGrid2(listSV);
            }
        }
        SinhVien sv2 = null;
        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                this.label2.Text = "Bạn đang chọn sinh viên : " + dataGridView2.Rows[e.RowIndex].Cells[2].Value.ToString();
                int idsv = int.Parse(dataGridView2.Rows[e.RowIndex].Cells[0].Value.ToString());
                sv2 = db.SinhViens.Where(p => p.ID == idsv).First();
            }
            catch
            {
                sv2 = null;
            }
        }
    }
}
