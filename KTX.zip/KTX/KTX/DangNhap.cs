﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KTX
{
    public partial class DangNhap : Form
    {
        KTX.QLKTXEntities db = new QLKTXEntities();
        public DangNhap()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(textBox1.Text != "" && textBox2.Text != "")
            {
                var x = db.Users.Where(p => p.Username == textBox1.Text && p.Password == textBox2.Text).ToList();
                if (x.Count > 0)
                {
                    Main m = new Main();
                    m.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Sai thông tin");
                }
            }
            else
            {
                MessageBox.Show("Hãy nhập đủ thông tin");
            }
        }

        private void DangNhap_Load(object sender, EventArgs e)
        {

        }
    }
}
