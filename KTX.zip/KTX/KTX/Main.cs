﻿using KTX.Shared;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KTX
{
    public partial class Main : Form
    {
        KTX.QLKTXEntities db = new QLKTXEntities();
        public Main()
        {
            InitializeComponent();
            StaticForm.Main = this;
            lblStatus.Text = db.Database.Connection.ConnectionString;
        }


        private void sinhViênToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSinhVien f = new FormSinhVien();
            f.MdiParent = this;
            f.StartPosition = FormStartPosition.CenterScreen;
            f.Show();
        }

        private void kýTúcXáToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormKTX f = new FormKTX();
            f.MdiParent = this;
            f.StartPosition = FormStartPosition.CenterScreen;
            f.Show();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void Main_Load(object sender, EventArgs e)
        {

        }
    }
}
